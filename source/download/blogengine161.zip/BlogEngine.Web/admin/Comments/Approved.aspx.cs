﻿using System;

public partial class admin_Comments_Approved : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
