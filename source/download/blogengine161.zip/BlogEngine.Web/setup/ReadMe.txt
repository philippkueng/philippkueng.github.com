BlogEngine.NET 1.6 supports a variety of data storage options out of the box.  By
default, it will store all data in XML files in your App_Data folder.  If you wish to
use a database to store your data, we have folders inside the setup folder to help you
get started with SQL Server, MySQL, SQLite, or VistaDB.  Any database that has an 
ADO.NET dll that supports DbProviderFactory can be used with some configuration.

Additional information can be found on our site at 
http://www.dotnetblogengine.net/